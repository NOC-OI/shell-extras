for datafile in "$@"
do
    echo $datafile
    bash goostats $datafile $datafile.stats
done
